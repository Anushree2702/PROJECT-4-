package com.example.productcatalog.controller;

public @interface Valid {
}
