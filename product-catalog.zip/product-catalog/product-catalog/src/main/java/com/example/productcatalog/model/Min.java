package com.example.productcatalog.model;

public @interface Min {
    int value();

    String message();
}
