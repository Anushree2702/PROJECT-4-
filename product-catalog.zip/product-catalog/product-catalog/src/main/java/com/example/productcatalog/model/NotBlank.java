package com.example.productcatalog.model;

public @interface NotBlank {
    String message();
}
